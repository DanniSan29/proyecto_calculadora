# Calculadora RNG (estructura modular)

Estructura modular con generadores y pruebas y GUI en Tkinter.

Archivos principales:
- generadores/*.py
- pruebas/*.py
- gui.py
- main.py
- requirements.txt

Ejecutar:
pip install -r requirements.txt
python main.py
